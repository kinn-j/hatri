/* Raman Rasoi website shell. Increase cache version when shipping changes. */
const CACHE = 'raman-rasoi-v1';
const SHELL = ['./', './index.html', './manifest.webmanifest',
  './icons/icon-192x192.png', './icons/icon-512x512.png',
  './icons/apple-touch-icon.png', './icons/favicon.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(names => Promise.all(names.filter(n => n !== CACHE).map(n => caches.delete(n)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req=event.request;
  if(req.method!=='GET' || new URL(req.url).origin !== self.location.origin) return;
  // Always try a fresh page first; use the cached shell if disconnected.
  if(req.mode==='navigate') {
    event.respondWith(fetch(req).then(res => {
      if(res.ok){const c=res.clone(); caches.open(CACHE).then(cache => cache.put('./index.html',c));}
      return res;
    }).catch(() => caches.match('./index.html')));
    return;
  }
  // Keep installed icons / manifest available offline; update other assets live.
  event.respondWith(fetch(req).then(res => {
    if(res.ok && (req.url.includes('/icons/') || req.url.endsWith('/manifest.webmanifest'))) {
      const c=res.clone(); caches.open(CACHE).then(cache => cache.put(req,c));
    }
    return res;
  }).catch(() => caches.match(req)));
});
